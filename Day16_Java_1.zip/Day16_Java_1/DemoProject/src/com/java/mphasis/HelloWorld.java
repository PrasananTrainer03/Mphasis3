package com.java.mphasis;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Welcome to Java Programming...");
	}
}
