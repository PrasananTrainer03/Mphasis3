package com.java.test;

public class ConEmploy {

	public static void main(String[] args) {
		Employ e1 = new Employ();
		System.out.println(e1);
		Employ e2 = new Employ(3, "Bala", 99234);
		System.out.println(e2);
	}
}
