package com.java.demo;

public class VotingException extends Exception {

	public VotingException() { }

	public VotingException(String error) {
		super(error);
	}
}
