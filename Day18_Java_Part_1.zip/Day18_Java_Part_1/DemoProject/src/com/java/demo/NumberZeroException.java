package com.java.demo;

public class NumberZeroException extends Exception {

	public NumberZeroException() {
		// TODO Auto-generated constructor stub
	}
	
	public NumberZeroException(String error) {
		super(error);
	}
}
