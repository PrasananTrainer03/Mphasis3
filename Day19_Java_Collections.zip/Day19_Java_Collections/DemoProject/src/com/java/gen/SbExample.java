package com.java.gen;

public class SbExample {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Welcome to Java Programming...");
		System.out.println(sb);
		sb.append("\n We are from Mphasis...");
		System.out.println(sb);
	}
}
