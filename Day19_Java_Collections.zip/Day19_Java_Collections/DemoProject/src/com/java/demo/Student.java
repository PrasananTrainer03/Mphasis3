package com.java.demo;

public class Student {

	private int sno;
	private String name;
	private String city;
	private double cgp;
	
	
}
