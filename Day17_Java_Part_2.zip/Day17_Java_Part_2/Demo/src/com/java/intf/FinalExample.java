package com.java.intf;

final class Admin {
	void branch() {
		System.out.println("its from Pune...");
	}
}

class Hr extends Admin {
	
}
public class FinalExample {

}
