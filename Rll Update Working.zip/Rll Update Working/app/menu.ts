export class Menu {
    public menuId : number;
    public restaurantId : number;
    public itemName : string;
    public menutype : string;
    public calories : number;
    public price : number;
    constructor() {

    }
}
