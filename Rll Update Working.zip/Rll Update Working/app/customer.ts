export class Customer {
    public customerid : number;
    public customername : string;
    public customermobile : string;
    public customercity : string;
    public customerstate : string;
    public customeremail : string;
    constructor() {

    }
}
