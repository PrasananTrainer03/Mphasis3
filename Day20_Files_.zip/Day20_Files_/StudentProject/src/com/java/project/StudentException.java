package com.java.project;

public class StudentException extends Exception {

	public StudentException() {
		// TODO Auto-generated constructor stub
	}
	
	public StudentException(String error) {
		super(error);
	}
}
