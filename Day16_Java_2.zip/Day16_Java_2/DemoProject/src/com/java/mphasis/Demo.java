package com.java.mphasis;

public class Demo {

	public void sowjanya() {
		System.out.println("Hi I am Sowjanya...");
	}
	
	void vineela() {
		System.out.println("Hi I am Vineela...");
	}
	
	private void srinadhi() {
		System.out.println("Hi I am Srinadhi...");
	}
}
