package com.java.mphasis;

public class Data {
	public static void main(String[] args) {
		Demo obj = new Demo();
		obj.sowjanya();
		obj.vineela();
	}
}
