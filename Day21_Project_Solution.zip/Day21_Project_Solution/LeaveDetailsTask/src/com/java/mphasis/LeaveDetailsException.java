package com.java.mphasis;

public class LeaveDetailsException extends Exception {

	LeaveDetailsException() {
		
	}
	
	LeaveDetailsException(String error) {
		super(error);
	}
}
