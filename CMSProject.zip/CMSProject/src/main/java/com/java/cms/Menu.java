package com.java.cms;

public class Menu {

	// private variables
	
	// getters and setters
	
	// toString()
}
