package com.java.cms;

public class RestaurantDAO {

	public List<Restaurant> showRestaurant() {
		
	}
	
	public Restaurant searchRestaurant(int restaurantId) {
		
	}
}
 