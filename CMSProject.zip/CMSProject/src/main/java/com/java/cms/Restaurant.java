package com.java.cms;

public class Restaurant {

	// private variables
	
	// getters and setters 
	
	// toString() 
}
