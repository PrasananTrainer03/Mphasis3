package com.java.cms;

public class CanteenMain {

	/*
	 * DAO to be be called in MAIN
	 * Menu as 
	 * 1) Show Restaurant
	 * 2) Search By Restaurant Id
	 * 3) Show Menu
	 * 4) Search Menu 
	 */
}
