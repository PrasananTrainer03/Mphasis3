package com.java.cms;

public class MenuDAO {

	public List<Menu> showMenu(int restaurantId) {
		
	}
	
	public Menu showMenuById(int menuId) {
		
	}
}
 