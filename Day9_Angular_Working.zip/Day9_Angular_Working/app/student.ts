export class Student {
    constructor(sno : number, name : string, cgp : number,city : number) {

    }
}

