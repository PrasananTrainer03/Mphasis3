import { Vendors } from './vendors';

describe('Vendors', () => {
  it('should create an instance', () => {
    expect(new Vendors()).toBeTruthy();
  });
});
