import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Vendors } from '../vendors';
import { VendorsService } from '../vendors.service';

@Component({
  selector: 'app-addvendor',
  templateUrl: './addvendor.component.html',
  styleUrls: ['./addvendor.component.css']
})
export class AddvendorComponent implements OnInit {
  addven:Vendors;
  ven:Observable<Vendors[]>
  price:number;
  msg: string;
    addvendor() {
      this._vendorService.addvendor(this.addven).subscribe(x => {
      this.msg = x;
      })
      alert("account created successfully")
      this.router.navigate(['/vendorauthenticate']);
    }
      constructor(private _vendorService:VendorsService,private router:Router) {
        this.addven= new Vendors();
       }
  ngOnInit(): void {
  }

}
