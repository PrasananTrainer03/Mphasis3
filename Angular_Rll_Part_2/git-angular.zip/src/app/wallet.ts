export class Wallet {
    public cus_ID : number;
    public wal_ID : number;
    public wal_AMOUNT: number;
    public wal_SOURCE : string;
    constructor() {
    }
}
