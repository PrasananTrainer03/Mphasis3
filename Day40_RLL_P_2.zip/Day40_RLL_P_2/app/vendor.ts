export class Vendor {
    public vendorid : number;
    public vendorname : string;
    public vendorstate : string;
    public vendorcity : string;
    public vendoremail : string;
    public vendormobile : string;
    constructor() {

    }
}
